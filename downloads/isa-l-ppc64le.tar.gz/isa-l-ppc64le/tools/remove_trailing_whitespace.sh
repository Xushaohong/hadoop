#!/bin/sh
sed -i -i.bak 's/[[:blank:]]*$//' "$@"
